# Frontend Mentor - Todo app

![Design preview for the Todo app coding challenge](./design/desktop-preview.jpg)

# Frontend Mentor - Todo app solution

This is a solution to the [Todo app challenge on Frontend Mentor](https://www.frontendmentor.io/challenges/todo-app-Su1_KokOW). Frontend Mentor challenges help you improve your coding skills by building realistic projects. 


## Welcome! 👋

Thanks for checking out this front-end coding challenge.
